// Application State
let appState = {
    currentTab: 'upload',
    uploadedData: null,
    cleanedData: null,
    selectedTemplate: null,
    weights: null,
    fileName: '',
    fileSize: 0,
    progress: 25
};

// Sample data from the application data
const sampleData = [
    {"id": 1, "region": "North", "income": 45000, "age": 34, "education": "Bachelor", "response": "Satisfied"},
    {"id": 2, "region": "South", "income": null, "age": 28, "education": "Master", "response": "Very Satisfied"},
    {"id": 3, "region": "East", "income": 67000, "age": 45, "education": "Bachelor", "response": "Neutral"},
    {"id": 4, "region": "West", "income": 52000, "age": null, "education": "PhD", "response": "Dissatisfied"},
    {"id": 5, "region": "North", "income": 38000, "age": 29, "education": "High School", "response": "Satisfied"},
    {"id": 6, "region": "South", "income": 75000, "age": 52, "education": "Master", "response": "Very Satisfied"},
    {"id": 7, "region": "East", "income": 41000, "age": 31, "education": "Bachelor", "response": "Neutral"},
    {"id": 8, "region": "West", "income": 89000, "age": 48, "education": "PhD", "response": "Very Satisfied"}
];

const cleaningMethods = {
    "imputation": ["Mean", "Median", "Mode", "KNN", "Forward Fill"],
    "outlierDetection": ["Z-Score", "IQR", "Isolation Forest", "Local Outlier Factor"],
    "validation": ["Range Check", "Format Validation", "Consistency Check", "Completeness Check"]
};

const reportTemplates = [
    {"name": "Standard Survey Report", "format": "PDF"},
    {"name": "Executive Summary", "format": "HTML"},
    {"name": "Detailed Analysis", "format": "PDF"},
    {"name": "Quick Overview", "format": "HTML"}
];

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    updateQuickStats();
});

function initializeApp() {
    // Set initial progress
    updateProgress();
    
    // Load sample data immediately for demonstration
    loadSampleData();
    displaySampleDataPreview();
    updateQuickStats();
    updateStatusIndicator('uploadStatus', 'Complete', 'success');
}

function setupEventListeners() {
    // Tab Navigation
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            switchTab(tab.dataset.tab);
        });
    });

    // File Upload
    const fileInput = document.getElementById('fileInput');
    if (fileInput) {
        fileInput.addEventListener('change', handleFileSelect);
    }
    
    // Drag & Drop
    const uploadZone = document.querySelector('.upload-zone');
    if (uploadZone) {
        uploadZone.addEventListener('click', () => {
            if (fileInput) fileInput.click();
        });
        uploadZone.addEventListener('dragover', handleDragOver);
        uploadZone.addEventListener('dragleave', handleDragLeave);
        uploadZone.addEventListener('drop', handleFileDrop);
    }

    // Data Cleaning
    const applyCleaningBtn = document.getElementById('applyCleaningBtn');
    if (applyCleaningBtn) {
        applyCleaningBtn.addEventListener('click', applyDataCleaning);
    }
    
    // Weighting
    const calculateWeightsBtn = document.getElementById('calculateWeightsBtn');
    if (calculateWeightsBtn) {
        calculateWeightsBtn.addEventListener('click', calculateWeights);
    }
    
    // Reports
    const templateOptions = document.querySelectorAll('.template-option');
    templateOptions.forEach(option => {
        option.addEventListener('click', () => selectTemplate(option.dataset.template));
    });
    
    const previewReportBtn = document.getElementById('previewReportBtn');
    if (previewReportBtn) {
        previewReportBtn.addEventListener('click', previewReport);
    }
    
    const generateReportBtn = document.getElementById('generateReportBtn');
    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', generateReport);
    }
    
    // Help Modal
    const helpBtn = document.getElementById('helpBtn');
    if (helpBtn) {
        helpBtn.addEventListener('click', () => openModal('helpModal'));
    }
    
    // Auto-update cleaning preview when options change
    const cleaningInputs = document.querySelectorAll('#imputationMethod, #outlierMethod, #outlierThreshold');
    cleaningInputs.forEach(input => {
        input.addEventListener('change', updateCleaningPreview);
    });
}

// Tab Management
function switchTab(tabName) {
    // Update tab buttons
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => {
        tab.classList.remove('active');
        if (tab.dataset.tab === tabName) {
            tab.classList.add('active');
        }
    });

    // Update tab content
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        content.classList.remove('active');
    });
    
    // Show the selected tab content
    const activeTabContent = document.getElementById(tabName + 'Tab');
    if (activeTabContent) {
        activeTabContent.classList.add('active');
    }

    appState.currentTab = tabName;
    updateProgress();
    
    // Initialize tab-specific content
    if (tabName === 'cleaning') {
        setTimeout(() => updateCleaningPreview(), 100);
    } else if (tabName === 'weighting') {
        populateWeightColumnSelector();
    }
}

function updateProgress() {
    const progressMap = {
        upload: 25,
        cleaning: 50,
        weighting: 75,
        reports: 100
    };
    
    appState.progress = progressMap[appState.currentTab] || 25;
    const progressFill = document.getElementById('progressFill');
    if (progressFill) {
        progressFill.style.width = appState.progress + '%';
    }
}

// File Upload Handling
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (file) {
        processUploadedFile(file);
    }
}

function handleDragOver(event) {
    event.preventDefault();
    const uploadZone = document.querySelector('.upload-zone');
    if (uploadZone) {
        uploadZone.classList.add('drag-over');
    }
}

function handleDragLeave(event) {
    event.preventDefault();
    const uploadZone = document.querySelector('.upload-zone');
    if (uploadZone) {
        uploadZone.classList.remove('drag-over');
    }
}

function handleFileDrop(event) {
    event.preventDefault();
    const uploadZone = document.querySelector('.upload-zone');
    if (uploadZone) {
        uploadZone.classList.remove('drag-over');
    }
    
    const files = event.dataTransfer.files;
    if (files.length > 0) {
        processUploadedFile(files[0]);
    }
}

function processUploadedFile(file) {
    showLoading();
    
    appState.fileName = file.name;
    appState.fileSize = file.size;
    
    // Simulate file processing
    setTimeout(() => {
        loadSampleData();
        hideLoading();
        
        // Show file info
        displayFileInfo(file);
        displaySchemaMapping();
        displayDataPreview();
        
        updateStatusIndicator('uploadStatus', 'Complete', 'success');
        updateQuickStats();
    }, 1500);
}

function loadSampleData() {
    appState.uploadedData = [...sampleData];
    appState.cleanedData = [...sampleData];
}

function displaySampleDataPreview() {
    // Show sample data immediately when app loads
    loadSampleData();
    displayFileInfo(null);
    displaySchemaMapping();
    displayDataPreview();
}

function displayFileInfo(file) {
    const fileInfo = document.getElementById('fileInfo');
    const fileDetails = document.getElementById('fileDetails');
    
    if (fileDetails) {
        fileDetails.innerHTML = `
            <div class="file-detail">
                <span class="detail-label">File Name</span>
                <span class="detail-value">${file ? file.name : 'sample_survey_data.csv'}</span>
            </div>
            <div class="file-detail">
                <span class="detail-label">File Size</span>
                <span class="detail-value">${file ? formatFileSize(file.size) : '2.3 KB'}</span>
            </div>
            <div class="file-detail">
                <span class="detail-label">Records</span>
                <span class="detail-value">${appState.uploadedData ? appState.uploadedData.length : 0}</span>
            </div>
            <div class="file-detail">
                <span class="detail-label">Columns</span>
                <span class="detail-value">${appState.uploadedData ? Object.keys(appState.uploadedData[0]).length : 0}</span>
            </div>
        `;
    }
    
    if (fileInfo) {
        fileInfo.classList.remove('hidden');
    }
}

function displaySchemaMapping() {
    const schemaMapping = document.getElementById('schemaMapping');
    const mappingGrid = document.getElementById('mappingGrid');
    
    if (!appState.uploadedData || !mappingGrid) return;
    
    const columns = Object.keys(appState.uploadedData[0]);
    const standardFields = ['ID', 'Region', 'Income', 'Age', 'Education Level', 'Response'];
    
    mappingGrid.innerHTML = columns.map((col, index) => `
        <div class="mapping-item">
            <span class="mapping-label">Column: ${col}</span>
            <select class="form-control" data-column="${col}">
                <option value="${col}">${standardFields[index] || col} (Auto-detected)</option>
                ${standardFields.map(field => 
                    `<option value="${field}">${field}</option>`
                ).join('')}
            </select>
        </div>
    `).join('');
    
    if (schemaMapping) {
        schemaMapping.classList.remove('hidden');
    }
}

function displayDataPreview() {
    const dataPreview = document.getElementById('dataPreview');
    const previewHeader = document.getElementById('previewHeader');
    const previewBody = document.getElementById('previewBody');
    
    if (!appState.uploadedData || !previewHeader || !previewBody) return;
    
    const columns = Object.keys(appState.uploadedData[0]);
    
    // Create header
    previewHeader.innerHTML = `
        <tr>
            ${columns.map(col => `<th>${col}</th>`).join('')}
        </tr>
    `;
    
    // Create body with first 10 rows
    previewBody.innerHTML = appState.uploadedData.slice(0, 10).map(row => `
        <tr>
            ${columns.map(col => `<td>${row[col] !== null ? row[col] : '<em>null</em>'}</td>`).join('')}
        </tr>
    `).join('');
    
    if (dataPreview) {
        dataPreview.classList.remove('hidden');
    }
}

// Data Cleaning
function updateCleaningPreview() {
    if (!appState.uploadedData) return;
    
    const beforeTable = document.getElementById('beforeTable');
    const afterTable = document.getElementById('afterTable');
    
    if (beforeTable && afterTable) {
        populateCleaningTable(beforeTable, appState.uploadedData, 'Before');
        
        // Simulate cleaned data
        const simulatedCleanedData = simulateDataCleaning(appState.uploadedData);
        populateCleaningTable(afterTable, simulatedCleanedData, 'After');
    }
}

function populateCleaningTable(table, data, title) {
    const columns = Object.keys(data[0]);
    
    const thead = table.querySelector('thead');
    const tbody = table.querySelector('tbody');
    
    if (thead) {
        thead.innerHTML = `
            <tr>
                ${columns.map(col => `<th>${col}</th>`).join('')}
            </tr>
        `;
    }
    
    if (tbody) {
        tbody.innerHTML = data.slice(0, 5).map(row => `
            <tr>
                ${columns.map(col => {
                    const value = row[col];
                    const cellClass = value === null ? 'missing-value' : '';
                    return `<td class="${cellClass}">${value !== null ? value : '<em>missing</em>'}</td>`;
                }).join('')}
            </tr>
        `).join('');
    }
}

function simulateDataCleaning(data) {
    const method = document.getElementById('imputationMethod')?.value || 'mean';
    const cleanedData = data.map(row => {
        const newRow = { ...row };
        
        // Handle missing income values
        if (newRow.income === null) {
            switch(method) {
                case 'mean':
                    newRow.income = 55000; // Simulated mean
                    break;
                case 'median':
                    newRow.income = 52000; // Simulated median
                    break;
                case 'mode':
                    newRow.income = 45000; // Simulated mode
                    break;
                default:
                    newRow.income = 50000; // Default imputation
            }
        }
        
        // Handle missing age values
        if (newRow.age === null) {
            newRow.age = 35; // Simulated imputation
        }
        
        return newRow;
    });
    
    return cleanedData;
}

function applyDataCleaning() {
    showLoading();
    
    setTimeout(() => {
        appState.cleanedData = simulateDataCleaning(appState.uploadedData);
        updateStatusIndicator('cleaningStatus', 'Complete', 'success');
        updateQuickStats();
        hideLoading();
        
        // Populate weight column selector
        populateWeightColumnSelector();
        
        // Show success message
        showNotification('Data cleaning applied successfully!', 'success');
    }, 2000);
}

// Survey Weighting
function populateWeightColumnSelector() {
    const weightColumn = document.getElementById('weightColumn');
    if (!weightColumn || !appState.cleanedData) return;
    
    const columns = Object.keys(appState.cleanedData[0]);
    
    weightColumn.innerHTML = '<option value="">Select column for weights</option>' +
        columns.map(col => `<option value="${col}">${col}</option>`).join('');
}

function calculateWeights() {
    showLoading();
    
    setTimeout(() => {
        const targetPop = parseInt(document.getElementById('targetPopulation')?.value || '10000000');
        const sampleSize = parseInt(document.getElementById('sampleSize')?.value || '1000');
        const baseWeight = parseFloat(document.getElementById('baseWeight')?.value || '1.0');
        
        // Simulate weight calculations
        const weights = appState.cleanedData.map(() => {
            return baseWeight * (targetPop / sampleSize) * (0.8 + Math.random() * 0.4);
        });
        
        appState.weights = weights;
        
        // Update weight statistics
        const minWeight = Math.min(...weights).toFixed(2);
        const maxWeight = Math.max(...weights).toFixed(2);
        const avgWeight = (weights.reduce((a, b) => a + b) / weights.length).toFixed(2);
        const marginError = (1.96 * Math.sqrt(1/sampleSize) * 100).toFixed(1);
        
        const elements = {
            minWeight: document.getElementById('minWeight'),
            maxWeight: document.getElementById('maxWeight'),
            avgWeight: document.getElementById('avgWeight'),
            marginError: document.getElementById('marginError')
        };
        
        if (elements.minWeight) elements.minWeight.textContent = minWeight;
        if (elements.maxWeight) elements.maxWeight.textContent = maxWeight;
        if (elements.avgWeight) elements.avgWeight.textContent = avgWeight;
        if (elements.marginError) elements.marginError.textContent = marginError + '%';
        
        updateStatusIndicator('weightingStatus', 'Complete', 'success');
        hideLoading();
        
        showNotification('Survey weights calculated successfully!', 'success');
    }, 1500);
}

// Report Generation
function selectTemplate(templateName) {
    appState.selectedTemplate = templateName;
    
    document.querySelectorAll('.template-option').forEach(option => {
        option.classList.remove('selected');
    });
    
    const selectedOption = document.querySelector(`[data-template="${templateName}"]`);
    if (selectedOption) {
        selectedOption.classList.add('selected');
    }
}

function previewReport() {
    if (!appState.selectedTemplate) {
        showNotification('Please select a report template first.', 'warning');
        return;
    }
    
    const previewArea = document.getElementById('reportPreviewArea');
    if (!previewArea) return;
    
    const templates = {
        standard: generateStandardReportPreview(),
        executive: generateExecutiveReportPreview(),
        detailed: generateDetailedReportPreview(),
        quick: generateQuickReportPreview()
    };
    
    previewArea.innerHTML = templates[appState.selectedTemplate] || templates.standard;
}

function generateStandardReportPreview() {
    return `
        <div class="report-preview">
            <h3>Standard Survey Report Preview</h3>
            <div class="report-section">
                <h4>Executive Summary</h4>
                <p>Survey analysis of ${appState.cleanedData?.length || 0} responses across 4 regions...</p>
            </div>
            <div class="report-section">
                <h4>Key Findings</h4>
                <ul>
                    <li>Average income: $55,250</li>
                    <li>Most common education: Bachelor's degree</li>
                    <li>Satisfaction rate: 75%</li>
                </ul>
            </div>
            <div class="report-section">
                <h4>Regional Distribution</h4>
                <p>Data includes responses from North, South, East, and West regions with balanced representation.</p>
            </div>
        </div>
    `;
}

function generateExecutiveReportPreview() {
    return `
        <div class="report-preview">
            <h3>Executive Summary Preview</h3>
            <div class="executive-highlights">
                <div class="highlight-box">
                    <span class="highlight-number">75%</span>
                    <span class="highlight-label">Overall Satisfaction</span>
                </div>
                <div class="highlight-box">
                    <span class="highlight-number">${appState.cleanedData?.length || 0}</span>
                    <span class="highlight-label">Total Responses</span>
                </div>
                <div class="highlight-box">
                    <span class="highlight-number">4</span>
                    <span class="highlight-label">Regions Covered</span>
                </div>
            </div>
            <p>High-level insights for strategic decision making...</p>
        </div>
    `;
}

function generateDetailedReportPreview() {
    return `
        <div class="report-preview">
            <h3>Detailed Analysis Preview</h3>
            <div class="analysis-section">
                <h4>Statistical Analysis</h4>
                <p>Comprehensive statistical breakdown including correlation analysis, regression models, and confidence intervals...</p>
                <h4>Data Quality Assessment</h4>
                <p>Missing data analysis, outlier detection results, and data validation outcomes...</p>
                <h4>Methodology</h4>
                <p>Survey design, sampling methodology, and weighting procedures...</p>
            </div>
        </div>
    `;
}

function generateQuickReportPreview() {
    return `
        <div class="report-preview">
            <h3>Quick Overview Preview</h3>
            <div class="quick-stats">
                <p><strong>Sample Size:</strong> ${appState.cleanedData?.length || 0} responses</p>
                <p><strong>Response Rate:</strong> 85%</p>
                <p><strong>Data Quality:</strong> High (95% complete)</p>
                <p><strong>Key Insight:</strong> Strong positive correlation between education and satisfaction</p>
            </div>
        </div>
    `;
}

function generateReport() {
    if (!appState.selectedTemplate) {
        showNotification('Please select a report template first.', 'warning');
        return;
    }
    
    showLoading();
    
    setTimeout(() => {
        updateStatusIndicator('reportStatus', 'Complete', 'success');
        updateSummaryStatistics();
        hideLoading();
        
        // Simulate file download
        const template = reportTemplates.find(t => 
            t.name.toLowerCase().replace(/\s+/g, '_') === appState.selectedTemplate
        );
        
        const templateName = template ? template.name : 'Survey Report';
        const templateFormat = template ? template.format : 'PDF';
        
        showNotification(`${templateName} (${templateFormat}) generated successfully!`, 'success');
        
        // Simulate download
        const link = document.createElement('a');
        link.download = `survey_report_${appState.selectedTemplate}.${templateFormat.toLowerCase()}`;
        link.href = '#';
        link.click();
    }, 2000);
}

function updateSummaryStatistics() {
    const totalResponses = appState.cleanedData?.length || 0;
    const validResponses = appState.cleanedData?.filter(row => 
        row.response && row.response !== null && row.response.trim() !== ''
    ).length || 0;
    const responseRate = totalResponses > 0 ? Math.round((validResponses / totalResponses) * 100) : 0;
    
    const elements = {
        totalResponses: document.getElementById('totalResponses'),
        validResponses: document.getElementById('validResponses'),
        responseRate: document.getElementById('responseRate')
    };
    
    if (elements.totalResponses) elements.totalResponses.textContent = totalResponses;
    if (elements.validResponses) elements.validResponses.textContent = validResponses;
    if (elements.responseRate) elements.responseRate.textContent = responseRate + '%';
}

// Utility Functions
function updateQuickStats() {
    if (!appState.uploadedData) return;
    
    const totalRecords = appState.uploadedData.length;
    const totalColumns = Object.keys(appState.uploadedData[0]).length;
    
    // Calculate missing data percentage
    let totalCells = totalRecords * totalColumns;
    let missingCells = 0;
    
    appState.uploadedData.forEach(row => {
        Object.values(row).forEach(value => {
            if (value === null || value === undefined || value === '') {
                missingCells++;
            }
        });
    });
    
    const missingPercentage = Math.round((missingCells / totalCells) * 100);
    
    const statElements = document.querySelectorAll('#quickStats .stat-item');
    if (statElements.length >= 3) {
        const recordsElement = statElements[0].querySelector('.stat-value');
        const columnsElement = statElements[1].querySelector('.stat-value');
        const missingElement = statElements[2].querySelector('.stat-value');
        
        if (recordsElement) recordsElement.textContent = totalRecords;
        if (columnsElement) columnsElement.textContent = totalColumns;
        if (missingElement) missingElement.textContent = missingPercentage + '%';
    }
}

function updateStatusIndicator(statusId, text, type) {
    const statusElement = document.getElementById(statusId);
    if (statusElement) {
        statusElement.textContent = text;
        statusElement.className = `status status--${type}`;
    }
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function showLoading() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
        loadingOverlay.classList.remove('hidden');
    }
}

function hideLoading() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
        loadingOverlay.classList.add('hidden');
    }
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('hidden');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('hidden');
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()" class="notification-close">×</button>
    `;
    
    // Add notification styles if not exist
    if (!document.querySelector('.notification-styles')) {
        const style = document.createElement('style');
        style.className = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: var(--color-surface);
                border: 1px solid var(--color-border);
                border-radius: var(--radius-base);
                padding: var(--space-16);
                box-shadow: var(--shadow-lg);
                z-index: 1500;
                display: flex;
                align-items: center;
                gap: var(--space-12);
                min-width: 300px;
                animation: slideIn 0.3s ease;
            }
            
            .notification--success {
                border-left: 4px solid var(--color-success);
            }
            
            .notification--error {
                border-left: 4px solid var(--color-error);
            }
            
            .notification--warning {
                border-left: 4px solid var(--color-warning);
            }
            
            .notification--info {
                border-left: 4px solid var(--color-info);
            }
            
            .notification-close {
                background: none;
                border: none;
                font-size: var(--font-size-lg);
                cursor: pointer;
                color: var(--color-text-secondary);
                padding: 0;
                margin-left: auto;
            }
            
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Global functions for modal controls
window.openModal = openModal;
window.closeModal = closeModal;